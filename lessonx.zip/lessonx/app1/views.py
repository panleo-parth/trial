from django.shortcuts import render
from .models import Login
import django.contrib.messages as messages
# Create your views here.

def index(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']


        if(Login.objects.filter(email_id=email) and email != ""):
            messages.warning(request, "Email exists !!!")
            return render(request, 'login.html', context={"msg":"Email exists!"})
        
        new_login = Login(name=name, email_id = email, password = password)
        new_login.save()
        messages.success(request, "Account created successfully !!!")
        return render(request, 'index.html', context={"msg":"Success!!!", "details":Login.objects.filter(email_id=email).values()})

    return render(request, 'index.html')

def login(request):
    return render(request, 'login.html')